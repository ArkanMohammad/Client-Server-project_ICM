package Client;

public interface Func {
	public void call();
}
